/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LinkedList.LinkeList;

/**
 *
 * @author Jawad Royesh
 */
public class Main {
    public static void main(String[] args){
        
    LinkedList list = new LinkedList();
    list.addLast(34);
    list.addLast(67);
    list.addLast(88);
    list.addLast(99);
    System.out.println("Befor Delelte ");
    list.display();
    list.addFirst(10);
    list.display();
    list.deleteLL(67);
    list.display();
    }
}
