/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LinkedList.Queue;

/**
 *
 * @author Jawad Royesh
 */
public class Main {
    public static void main(String[] args){
    
        Qeueue queue = new Qeueue();
        queue.enqueue(23);
        queue.enqueue(56);
        queue.enqueue(66);
        queue.display();
//        queue.display();
//        queue.display();
        System.out.println("\nItem dequeded " + queue.dequeue());
        System.out.println("\nItem dequeded " + queue.dequeue());
        System.out.println("\nItem dequeded " + queue.dequeue());
    }
}
