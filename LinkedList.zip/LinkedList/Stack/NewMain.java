/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package LinkedList.Stack;

/**
 *
 * @author Jawad Royesh
 */
public class NewMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Stack stack = new Stack();
       stack.push(12);
       stack.push(32);
       stack.push(33);
       stack.push(65);
       stack.display();
//       stack.display();
//       stack.display();
//       stack.display();
//       stack.display();
//        stack.pop();

    }
    
}
