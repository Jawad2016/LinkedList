/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LinkedList.LinkeList;

/**
 *
 * @author Jawad Royesh
 */
public class LinkedList {
    Node head;

    public LinkedList() {
        this.head = null;
    }
    
    public void  addFirst(int item){
        Node oldhead = head;
         head = new Node(item,oldhead);
    }
    public void addLast(int item){
    
        Node newnode = new Node(item,null);
        
        if(head == null){
        
            head = newnode;
        }
        else {
        Node temp = head;
        while(temp.next != null){
            temp = temp.next;
        }
        temp.next = newnode;
        
        }
    }
    public void deleteLL(int item){
    
        Node temp = head;
        Node prev = null;
        if(temp.next != null && temp.data == item){
            head = temp.next;
        }
        else {
        
            while(temp.next !=null && temp.data != item){
                prev = temp;
                temp = temp.next;
            }
            prev.next = temp.next;
            System.out.println(item + " Successfully deleted!");
        }
    
    }
    public void display(){
        Node temp = head;
        while(temp !=null){
        
            System.out.print(temp.data + "->");
            temp = temp.next;
        }
       System.out.println();
    }
}
