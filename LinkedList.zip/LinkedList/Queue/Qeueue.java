/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LinkedList.Queue;

/**
 *
 * @author Jawad Royesh
 */
public class Qeueue {
    Node front;
    Node rear;

    public Qeueue() {
        this.front = null;
        this.rear = null;
    }
    public boolean isEmpty(){
    
        return rear == null;
    }
    public void enqueue(int item){
        Node newnode = new Node(item);
         if(isEmpty()){
        
            rear = front = newnode;
        }
         else {
        rear.next = newnode;
        rear = newnode;
        
         }
    }
    public int dequeue(){
    
        if(isEmpty()){
        
            System.out.println("Qeueue is empty, could not to be deleted");
            return -1;
        }
        else {
            int dequed = front.data;
            front = front.next;
            return dequed;
        }
    }
    public void display(){ // ---------------O(n)
        if(isEmpty()){
        
            System.out.println("Stack is empty, no datat to display");
        }
        Node temp = front;
        while(temp != null){
            System.out.println("[" +temp.data +"]"+ " ");
            temp = temp.next;
        }
    }
    
}
