/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LinkedList.Stack;

/**
 *
 * @author Jawad Royesh
 */
public class Stack {
    Node top;
    
    public Stack() {
        this.top = null;
        
    }
    
    public boolean isEmpty(){
    
        return top == null;
    }
    public void push(int item){
    
        Node newnode = new Node(item);
        if(isEmpty()){
        
            top = newnode;
            
        }
        else {
        
            newnode.next = top;
//            System.out.println(top.data + "successfully added");
            top = newnode;
        }
    }
    
    public int pop(){
    
        if(isEmpty()){
        
            System.out.println("Stack is empty, can't be to delete ");
            return -1;
        }
        else {
        
            int poped = top.data;
            top.next = top;
            System.out.println(poped);
            return poped;
        }
    }
    
    public void display(){
        if(isEmpty()){
        
            System.out.println("Stack is empty , no data to display");
        }
        Node temp = top;
//        System.out.println("temp "+ temp.data);
        if(isEmpty()){
        
            System.out.println("Stack is empty, no data to display");
        }
        while(temp != null){
            System.out.println(temp.data);
            temp = temp.next;
        }
    }
    
    
}
